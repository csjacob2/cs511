import java.util.List;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.IOException;


public class TokenizerDriver {
    public static void main (String[] args) {
        String filename = "new.txt";

        Tokenizer tz = new Tokenizer();

        List<List<String>> reviews = tz.tokenizeReviews(filename);

        // System.out.println(reviews);


        // for (List<String> r: reviews) {
        //     System.out.println(r);
        // }


        writeReviews(reviews);


        System.out.println("success");
    }    

    public static void printReviews (List<List<String>> reviews) {
        for (List<String> r: reviews) {
            for (String t : r) {
                System.out.println(t);
            }
        }
    }
    public static void writeReviews (List<List<String>> reviews) {
        try {
            PrintWriter writer = new PrintWriter("new_token.txt", "UTF-8");
            for (List<String> r: reviews) {
                for (String t : r) {
                    writer.println(t);
                }
                writer.println();
            }
            writer.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}


