import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;



public class Tokenizer {


    public List<List<String>> tokenizeReviews(String filename) {
        // IO
        File file = new File(filename);
        BufferedReader reader = null;

        // Vars
        List<List<String>> result = new ArrayList<List<String>>();
        int linecount = 0;

        try {
            // Open file
            reader = new BufferedReader(new FileReader(file));

            String line = null;
            List<String> review = new ArrayList<String>();

            while ((line = reader.readLine()) != null) {
                if (line.equals("")) {
                    // System.out.println(review);
                    result.add(review);
                    review = new ArrayList<String>();
                } else {
                    tokenize(review,line);
                }

                // if (++linecount == 10)
                //     break;
            }
            result.add(review);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
            }
        }

        return result;

    }

    public List<String> tokenize (String line) {
        List<String> tokens = new ArrayList<String>();
        String[] words = line.split(" ");

        for (String w : words) {
            if (!w.equals('\n'))
                tokens.add(w);
        }
        return tokens;
    }
    public void tokenize (List<String> review, String line) {
        List<String> lineTokens = tokenize(line);
        // System.out.println(lineTokens);
        for (String t : lineTokens) {
            review.add(t);
        }
    }



    // Read each line, tokenize the word based on space delimiter
    // Return list of token words
    public List<String> tokenizeWords(String filename) {
        List<String> result = new ArrayList<String>();
        File file = new File(filename);
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(file));
            String line = null;

            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(" ");

                for (String token : tokens) {
                    result.add(token);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
            }
        }

        return result;
    }
}

